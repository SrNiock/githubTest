# Gestor de Fotos en Kotlin

Este proyecto es una aplicación de consola desarrollada en Kotlin que permite administrar una colección de fotos digitales.  
Los datos se guardan en un archivo binario de acceso directo llamado *fotos.bin*, lo que permite leer, modificar y eliminar registros de manera eficiente.


## 1. Estructura de datos

### **Data Class**
```kotlin
data class FotoBinaria(
    val id: Int,
    val nombre: String,
    val fecha: String,
    val tipoDeArchivo: String,
    val peso: Double,
    val favorito: Boolean
)
```
### **Estructura del registro binario:**
- **id**: Int - 4 bytes
- **nombre**: String - 20 bytes (longitud fija)
- **fecha**: String - 20 bytes (longitud fija)
- **tipoDeArchivo**: String - 20 bytes (longitud fija)
- **peso**: Double - 8 bytes
- **favorito**: Boolean - 1 byte
- **Tamaño Total del Registro**: 4 + 20 + 20 + 20 + 8 + 1 = 73 bytes

## 2. Instrucciones de ejecución
- **Requisitos previos**: Asegúrate de tener un JDK (ej. versión 17 o
  superior) instalado.
- **Compilación**: Abre el proyecto en IntelliJ IDEA y deja que Gradle
  sincronice las dependencias.
- **Ejecución**: Ejecuta la función main del fichero Main.kt.
- **Ficheros necesarios**: El programa espera encontrar un fichero
  *mis_fotos.json* en la carpeta *datos_ini* dentro de la raíz del proyecto
  para la carga inicial de datos.
## 3. Decisiones de diseño
- Elegí JSON para los datos iniciales porque permite intercambiar información fácilmente y es muy legible, además de facilitar la carga inicial de datos al programa.
- Decidí que los campos de texto como **nombre**, **fecha** y **tipoDeArchivo** tuvieran 20 bytes cada uno, suficiente para la mayoría de entradas sin desperdiciar espacio en el fichero binario.
- El campo **peso** se almacena como **Double** de 8 bytes para poder manejar valores decimales con precisión.
- El campo **favorito** se almacena como **Boolean** en 1 byte, optimizando la memoria.
- Se utiliza `ByteBuffer` y `FileChannel` para leer y escribir registros binarios de forma eficiente, permitiendo modificar valores concretos sin reescribir todo el fichero.
- La validación de entradas del usuario se hace con `toIntOrNull()` y bucles de comprobación, evitando que el programa se bloquee por valores inválidos.
- Para eliminar registros se crea un fichero temporal, asegurando que la operación sea segura y evitando corrupción del fichero original.  
- Al añadir una nueva entrada se detecta la ultima id para que se genere una que continue la secuencua de numeros, esto evita que se repita la id.