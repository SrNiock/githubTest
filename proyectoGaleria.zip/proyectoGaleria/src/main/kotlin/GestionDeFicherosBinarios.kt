import kotlinx.serialization.json.Json
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.charset.Charset
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import java.nio.file.StandardOpenOption

data class FotoBinaria(val id: Int, val nombre:String, val fecha:String,val tipoDeArchivo:String, val peso: Double, val favorito: Boolean)

const val TAMANO_ID  = Int.SIZE_BYTES
const val TAMANO_NOMBRE = 20
const val TAMANO_FECHA = 20
const val TAMANO_TIPODEARCHIVO = 20
const val TAMANO_PESO = Double.SIZE_BYTES
const val TAMANO_FAVORITO = 1
const val TAMANO_REGISTRO = TAMANO_ID+TAMANO_NOMBRE+TAMANO_FECHA+TAMANO_TIPODEARCHIVO+TAMANO_PESO+TAMANO_FAVORITO

fun vaciarCrearFichero(path: Path){
    try{
        FileChannel.open(path, StandardOpenOption.WRITE, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING).close()
        println("EL fichero ${path.fileName} exite y esta vacio")
    }catch (e: Exception){
        println("Error al vaciar o crear el fichero: ${e.message}")
    }

}

fun anadir(path: Path,id : Int,nombre:String,fecha:String,tipoDeArchivo: String,peso: Double,favorito: Boolean){

    val nuevaFoto = FotoBinaria(id,nombre,fecha,tipoDeArchivo,peso,favorito)

    try{
        FileChannel.open(path, StandardOpenOption.WRITE, StandardOpenOption.CREATE, StandardOpenOption.APPEND).use{canal ->
            val buffer = ByteBuffer.allocate(TAMANO_REGISTRO)

            //id
            buffer.putInt(nuevaFoto.id)
            //nombre
            val nombreBytes = nuevaFoto.nombre
                .padEnd(20,' ')
                .toByteArray(Charset.defaultCharset())
            buffer.put(nombreBytes,0,20)
            //fecha
            val fechaBytes = nuevaFoto.fecha
                .padEnd(20,' ')
                .toByteArray(Charset.defaultCharset())
            buffer.put(fechaBytes,0,20)

            //tipoDeArchivo
            val tipoByte = nuevaFoto.tipoDeArchivo
                .padEnd(20,' ')
                .toByteArray(Charset.defaultCharset())
            buffer.put(tipoByte,0,20)

            //peso
            buffer.putDouble(nuevaFoto.peso)

            //favorito
            buffer.put(if (nuevaFoto.favorito) 1.toByte() else 0.toByte())

            buffer.flip()

            while(buffer.hasRemaining()){
                canal.write(buffer)
            }
            println("Foto ${nuevaFoto.nombre} añadida con exito.")
        }
    }catch (e: Exception){
        println("Error al añadir la planta: ${e.message}")
    }
}


fun leerFotos(path: Path) : List<FotoBinaria>{
    val fotos = mutableListOf<FotoBinaria>()

    FileChannel.open(path, StandardOpenOption.READ).use{ canal ->

        val buffer = ByteBuffer.allocate(TAMANO_REGISTRO)

        while(canal.read(buffer) > 0){
            buffer.flip()
            //id
            val id = buffer.getInt()
            //nombre
            val nombreBytes = ByteArray(TAMANO_NOMBRE)
            buffer.get(nombreBytes)
            val nombre = String(nombreBytes, Charset.defaultCharset()).trim()

            //fecha
            val fechaBytes = ByteArray(TAMANO_FECHA)
            buffer.get(fechaBytes)
            val fecha = String(fechaBytes, Charset.defaultCharset()).trim()

            //tipoDeArchivo
            val tipoBytes = ByteArray(TAMANO_TIPODEARCHIVO)
            buffer.get(tipoBytes)
            val tipoDeArchivo = String(tipoBytes, Charset.defaultCharset()).trim()
            //peso
            val peso = buffer.getDouble()

            //favorito
            val favoritoByte = buffer.get()
            val favorito = favoritoByte.toInt() != 0

            buffer.clear()
            fotos.add(FotoBinaria(id, nombre, fecha, tipoDeArchivo, peso, favorito))

        }

    }
    return fotos
}

fun importarJSON(rutaJSON: Path,rutaBIN: Path){
    val json = Json { prettyPrint = true }

    var fotos: List<FotoJSON> = emptyList()
    val jsonString = Files.readString(rutaJSON)

    fotos = json.decodeFromString<List<FotoJSON>>(jsonString)

    val datos: List<FotoJSON> = fotos

    for(dato in datos){
        anadir(rutaBIN,dato.id,dato.nombre,dato.fecha,dato.tipoDeArchivo,dato.peso,dato.favorito)
    }



}


fun modificar(path : Path){
    FileChannel.open(path, StandardOpenOption.READ, StandardOpenOption.WRITE).use{canal ->
        var buffer = ByteBuffer.allocate(TAMANO_REGISTRO)
        var encontrado = false

        println("Dime la ID de la foto que quieres modificar el estado")
        var idFoto = readln().toIntOrNull()

        println("Marcar foto como favorita (Y/N):")
        var respuesta = readln().uppercase()
        while (respuesta != "Y" && respuesta != "N") {
            println("Introduce un valor válido (Y/N):")
            respuesta = readln().uppercase()
        }
        val nuevoEstado = respuesta =="Y"


        println("Dime el nuevo nombre")
        var nuevoNombre = readln()


        while(canal.read(buffer)> 0 && ! encontrado){
            val posicionActual = canal.position()
            buffer.flip()
            val id = buffer.getInt()
            if(id == idFoto){
                val posicionEstado = posicionActual - TAMANO_REGISTRO + TAMANO_ID + TAMANO_NOMBRE +TAMANO_FECHA+ TAMANO_TIPODEARCHIVO +TAMANO_PESO
                val bufferFavorito = ByteBuffer.allocate(TAMANO_FAVORITO)
                bufferFavorito.put(if (nuevoEstado) 1.toByte() else 0.toByte())
                bufferFavorito.flip()
                canal.write(bufferFavorito,posicionEstado)

                val posicionEstado2 = posicionActual - TAMANO_REGISTRO + TAMANO_ID
                val bufferFavorito2 = ByteBuffer.allocate(TAMANO_NOMBRE)
                //nombre
                val nombreBytes = nuevoNombre
                    .padEnd(20,' ')
                    .toByteArray(Charset.defaultCharset())
                bufferFavorito2.put(nombreBytes,0,20)
                bufferFavorito2.flip()
                canal.write(bufferFavorito2,posicionEstado2)



                encontrado = true
            }
            buffer.clear()

        }
        if (encontrado) {
            println("Estado 'favorito' de la foto con ID $idFoto modificado a $nuevoEstado y nombre modificado a $nuevoNombre")
        } else {
            println("No se encontró ninguna foto con ID $idFoto")
        }
    }
}




fun modificarPesoFoto(path: Path, idFoto:Int, nuevoPeso: Double){

    FileChannel.open(path, StandardOpenOption.READ, StandardOpenOption.WRITE).use{ canal ->
        val buffer = ByteBuffer.allocate(TAMANO_REGISTRO)
        var encontrado = false
        while(canal.read(buffer)> 0 && ! encontrado){
            val posicionActual = canal.position()
            buffer.flip()

            val id = buffer.getInt()
            if(id == idFoto){
                val posicionPeso = posicionActual - TAMANO_REGISTRO + TAMANO_ID + TAMANO_NOMBRE +TAMANO_FECHA+ TAMANO_TIPODEARCHIVO
            val bufferPeso = ByteBuffer.allocate(TAMANO_PESO)
                bufferPeso.putDouble(nuevoPeso)
                bufferPeso.flip()

                canal.write(bufferPeso,posicionPeso)
                encontrado = true
            }
            buffer.clear()
        }
        if(encontrado){
            println("Peso FOto $idFoto modificadoa  $nuevoPeso")
        }else{
            println("NO se encontro XD")
        }
    }




}

fun mostrarTodos(path: Path){
    val leidas = leerFotos(path)

    println("FOTOS LEIDAS: ")

    for (dato in leidas) {
        println(" - ID: ${dato.id}, Nombre: ${dato.nombre}, Fecha: ${dato.fecha}, " +
                "Tipo: ${dato.tipoDeArchivo}, Peso: ${dato.peso}MB, Favorito: ${dato.favorito}")
    }


}


fun nuevoReg(path: Path){
    val leidas = leerFotos(path)
    var peso: Double? = null
    val ultimaId = leidas.lastOrNull()?.id ?: 0


    var id = ultimaId+1
    println("Añadiendo un nuevo registro a Foto con ID $id")

    println("Dime el nombre")
    var nombre = readln()

    println("Dime la fecha")
    var fecha = readln()

    println("Dime el tipo de archivo")
    var tipoDeArchivo = readln()

    do{
        println("Dime el peso del archivo")
         peso = readln().toDoubleOrNull()
        if(peso == null)println("Introduce un peso valido.")
    } while(peso == null)

    println("Marcar foto como favorita (Y/N):")
    var respuesta = readln().uppercase()
    while (respuesta != "Y" && respuesta != "N") {
        println("Introduce un valor válido (Y/N):")
        respuesta = readln().uppercase()
    }
    val favorito = respuesta =="Y"

    val nuevaFoto = FotoBinaria(id,nombre,fecha,tipoDeArchivo,peso,favorito)

    try{
        FileChannel.open(path, StandardOpenOption.WRITE, StandardOpenOption.CREATE, StandardOpenOption.APPEND).use{canal ->
            val buffer = ByteBuffer.allocate(TAMANO_REGISTRO)

            //id
            buffer.putInt(nuevaFoto.id)
            //nombre
            val nombreBytes = nuevaFoto.nombre
                .padEnd(20,' ')
                .toByteArray(Charset.defaultCharset())
            buffer.put(nombreBytes,0,20)
            //fecha
            val fechaBytes = nuevaFoto.fecha
                .padEnd(20,' ')
                .toByteArray(Charset.defaultCharset())
            buffer.put(fechaBytes,0,20)

            //tipoDeArchivo
            val tipoByte = nuevaFoto.tipoDeArchivo
                .padEnd(20,' ')
                .toByteArray(Charset.defaultCharset())
            buffer.put(tipoByte,0,20)

            //peso
            buffer.putDouble(nuevaFoto.peso)

            //favorito
            buffer.put(if (nuevaFoto.favorito) 1.toByte() else 0.toByte())

            buffer.flip()

            while(buffer.hasRemaining()){
                canal.write(buffer)
            }
            println("Foto ${nuevaFoto.nombre} añadida con exito.")
        }
    }catch (e: Exception){
        println("Error al añadir la planta: ${e.message}")
    }

}

fun eliminar(path: Path){
    println("Dime la ID de la foto que deseas eliminar,por favor")
    var idFoto = readln().toIntOrNull()

    val pathTemporal = Paths.get(path.toString() +".tmp")
    var fotoEncontrado = false

    FileChannel.open(path, StandardOpenOption.READ).use{canalLectura ->

        FileChannel.open(pathTemporal, StandardOpenOption.WRITE, StandardOpenOption.CREATE).use{ canalEscritura ->
            val buffer = ByteBuffer.allocate(TAMANO_REGISTRO)

            while(canalLectura.read(buffer) >0){
                buffer.flip()
                val id = buffer.getInt()
                if(id == idFoto){
                    fotoEncontrado =true
                }else{
                    buffer.rewind()
                    canalEscritura.write(buffer)
                }
                buffer.clear()
            }

        }

    }

    if(fotoEncontrado){
        Files.move(pathTemporal,path, StandardCopyOption.REPLACE_EXISTING)
        println("Foto con ID $idFoto eliminada con exito!")

    }else{
        Files.delete(pathTemporal)
        println("No se encontro ninguna planta con ID $idFoto")
    }

}
