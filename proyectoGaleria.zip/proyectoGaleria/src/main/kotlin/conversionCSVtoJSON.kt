import com.github.doyaaaaaken.kotlincsv.dsl.csvReader
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.nio.file.Files
import java.nio.file.Path


fun leerDatosInicialesCSV1(ruta: Path) : List<FotoCSV>{

    var fotos: List<FotoCSV> = emptyList()

    if(!Files.isReadable(ruta)){
        println("Error no se puede leer el fichero en la ruta: $ruta")
    }else{
        val reader = csvReader{
            delimiter = ';'
        }

        val filas: List<List<String>> = reader.readAll(ruta.toFile())

        fotos = filas.mapNotNull { columnas->
            if(columnas.size >= 6){
                try {
                    val id = columnas[0].toInt()
                    val nombre = columnas[1]
                    val fecha = columnas[2]
                    val tipoDeArchivo = columnas[3]
                    val peso = columnas[4].toDouble()
                    val favorito = columnas[5].toBoolean()
                    FotoCSV(id,nombre,fecha, tipoDeArchivo,peso,favorito)
                }catch (e: Exception){
                    println("Fila invalida ignorada: $columnas -> ERROR: ${e.message}")
                    null
                }

        }else{
            println("Fila con formato incorrecto ignorada: $columnas")
                null
            }
        }
    }
        return fotos
}

fun escribirDatosJSON1(ruta: Path,fotos : List<FotoJSON>){

    try{
        val json = Json{prettyPrint = true}.encodeToString(fotos)

        Files.writeString(ruta,json)
        println("Info guardad en $ruta")
    }catch (e: Exception){
        println("Error ${e.message}")
    }

}