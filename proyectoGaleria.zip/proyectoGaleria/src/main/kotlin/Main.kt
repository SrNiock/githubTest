import java.nio.file.Path
import java.nio.file.Paths
fun main() {
    ComprobarFicheros()
    var entrada:String
    val archivoPath: Path = Paths.get("datos_fin/fotos.bin")
    val archivoJSON: Path = Paths.get("datos_ini/mis_fotos.json")
    //vaciarCrearFichero(archivoPath)
    //importarJSON(archivoJSON,archivoPath)
    do {
    println("\nMENU PRINCIPAL:\n1.Mostrar todos los registros\n2.Añadir un nuevo registro\n3.Modificar un registro(por ID)\n4.Eliminar un registro(por ID)\n5.SALIR")
    entrada = readln()
        val entradaEntero: Int? = entrada.toIntOrNull()
        when(entradaEntero){
            1 -> mostrarTodos(archivoPath)
            2 -> nuevoReg(archivoPath)
            3 -> modificar(archivoPath)
            4 -> eliminar(archivoPath)
            5 -> println("---PROGRAMA CERRADO---")
        else ->{println("Opcion no valida, introduce un nuemro del 1 al 5") }
        }
    }while(entradaEntero!=5)
}