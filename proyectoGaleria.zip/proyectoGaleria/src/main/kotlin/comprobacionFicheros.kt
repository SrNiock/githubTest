import java.nio.file.Files
import java.nio.file.Path
import kotlin.io.path.exists


fun ComprobarFicheros() {
    //Definicion de rutas
    val datos_ini = Path.of("datos_ini")
    val datos_fin = Path.of("datos_fin")

    val listaCarpetas: List<Path> = listOf(datos_ini,datos_fin)
    val objetivo = "mis_fotos.json"
    var señal: Boolean = false
    var capetaContenedor:String =""
    val rutaJson = datos_ini.resolve(objetivo)

    //Comprobacion y creacion de carpetas
    for (i in listaCarpetas){
    if (i.exists()) {
        println("La carpeta $i existe")
    } else {
        println("Creando carpeta $i")
        Files.createDirectories(i)
        }
        Files.walk(i).use {
            stream ->
            stream.sorted().forEach { path ->
                if(path.fileName.toString() == objetivo){
                    señal = true
                    capetaContenedor = i.fileName.toString();
                }
            }
        }
    }
    if(señal){
        println("\n[FILE] $objetivo ENCONTRADO EN [DIR]$capetaContenedor")
    } else {
        println("[FILE] $objetivo NO se encontró en ${datos_ini.fileName}, el programa no podrá importar datos iniciales.")
        if (!Files.exists(rutaJson.parent)) {
            Files.createDirectories(rutaJson.parent)
        }
        Files.writeString(rutaJson, "[]")
    }
}