import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty

import com.fasterxml.jackson.dataformat.xml.XmlMapper
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement
import com.fasterxml.jackson.module.kotlin.readValue
import com.fasterxml.jackson.module.kotlin.registerKotlinModule
import java.io.File
import java.nio.file.Path


data class FotoXML(
    @JacksonXmlProperty(localName = "id")
    val id: Int,
    @JacksonXmlProperty(localName = "nombre")
    val nombre:String,
    @JacksonXmlProperty(localName = "tipoDeArchivo")
    val tipoDeArchivo:String,
    @JacksonXmlProperty(localName = "peso")
    val peso: Double,
    @JacksonXmlProperty(localName = "favorito")
    val favorito: Boolean
)
@JacksonXmlRootElement(localName = "fotos")

data class Fotos(
    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "foto")
    val listaFotos: List<FotoXML> = emptyList()


)

fun leerDatosInicialesXML(ruta: Path): List<FotoXML>{
    val fichero: File = ruta.toFile()
    val xmlMapper = XmlMapper().registerKotlinModule()
    val fotosWrapper: Fotos = xmlMapper.readValue(fichero)
    return fotosWrapper.listaFotos
}

fun escribirDatosXML(ruta: Path, fotos:List<FotoXML>){
    try{
        val fichero: File = ruta.toFile()
        val contenedorXml = Fotos(fotos)
        val xmlMapper = XmlMapper().registerKotlinModule()

        val xmlString =
            xmlMapper.writerWithDefaultPrettyPrinter().writeValueAsString(contenedorXml)

        fichero.writeText(xmlString)
        println("\nInformacion guardad en: $fichero")
    }catch (e: Exception){
        println("Error:  ${e.message}")
    }


}