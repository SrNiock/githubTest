import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.nio.file.Files
import java.nio.file.Path

@Serializable
data class FotoJSON(val id: Int,val nombre:String, val fecha:String, val tipoDeArchivo:String, val peso:Double, val favorito: Boolean)


fun leerDatosInicialesJSON(ruta: Path): List<FotoJSON>{
    var fotos: List<FotoJSON> = emptyList()
    val jsonString = Files.readString(ruta)

    fotos = Json.decodeFromString<List<FotoJSON>>(jsonString)
    return fotos
}

fun escribirDatosJSON(ruta: Path,fotos : List<FotoJSON>){

    try{
        val json = Json{prettyPrint = true}.encodeToString(fotos)

        Files.writeString(ruta,json)
        println("Info guardad en $ruta")
    }catch (e: Exception){
        println("Error ${e.message}")
    }

}



