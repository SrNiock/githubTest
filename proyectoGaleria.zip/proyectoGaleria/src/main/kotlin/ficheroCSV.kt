import com.github.doyaaaaaken.kotlincsv.dsl.csvReader
import com.github.doyaaaaaken.kotlincsv.dsl.csvWriter
import java.io.File
import java.nio.file.Files
import java.nio.file.Path


data class FotoCSV(val id: Int,val nombre:String, val fecha:String, val tipoDeArchivo:String, val peso:Double, val favorito: Boolean)


fun main(){

    val entradaCSV = Path.of("datos_ini/mis_fotos.csv")
    val salidaCSV = Path.of("datos_ini/mis_fotos2.csv")

    val datos: List<FotoCSV>

    datos = leerDatosInicialesCSV(entradaCSV)
    for(dato in datos){
        println("-ID ${dato.id}, Nombre ${dato.nombre}, Fecha: ${dato.fecha}, Tipo de archivo: ${dato.tipoDeArchivo}, Peso: ${dato.peso}, Favorito: ${dato.peso}")
    }
    escribirDatosCSV(salidaCSV,datos)
}

fun leerDatosInicialesCSV(ruta: Path) : List<FotoCSV>{

    var fotos: List<FotoCSV> = emptyList()

    if(!Files.isReadable(ruta)){
        println("Error no se puede leer el fichero en la ruta: $ruta")
    }else{
        val reader = csvReader{
            delimiter = ';'
        }

        val filas: List<List<String>> = reader.readAll(ruta.toFile())

        fotos = filas.mapNotNull { columnas->
            if(columnas.size >= 6){
                try {
                    val id = columnas[0].toInt()
                    val nombre = columnas[1]
                    val fecha = columnas[2]
                    val tipoDeArchivo = columnas[3]
                    val peso = columnas[4].toDouble()
                    val favorito = columnas[5].toBoolean()
                    FotoCSV(id,nombre,fecha, tipoDeArchivo,peso,favorito)
                }catch (e: Exception){
                    println("Fila invalida ignorada: $columnas -> ERROR: ${e.message}")
                    null
                }

        }else{
            println("Fila con formato incorrecto ignorada: $columnas")
                null
            }
        }
    }
        return fotos
}

fun escribirDatosCSV(ruta: Path,fotos: List<FotoCSV>){

    try{
        val fichero: File = ruta.toFile()

        csvWriter {
            delimiter = ';'
        }.writeAll(
            fotos.map { foto ->
                listOf(foto.id.toString(),
                    foto.nombre,
                    foto.fecha,
                    foto.tipoDeArchivo,
                    foto.peso.toString(),
                    foto.favorito.toString()
                    )
            },fichero
        )
        println("\nInformacion guardada en: $fichero")
    }catch (e: Exception){
        println("Error: ${e.message}")
    }
}